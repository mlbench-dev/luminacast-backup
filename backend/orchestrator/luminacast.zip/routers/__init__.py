"""FastAPI route handlers."""
