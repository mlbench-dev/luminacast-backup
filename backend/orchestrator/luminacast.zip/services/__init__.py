"""External service adapters."""
