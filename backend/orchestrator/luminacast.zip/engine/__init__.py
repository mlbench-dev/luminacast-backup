"""Core business logic engine."""
